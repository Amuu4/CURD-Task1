﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using CRUD_Application_2.Model;

namespace CRUD_Application_2.Data
{
    public class CRUD_Application_2Context : DbContext
    {
        public CRUD_Application_2Context (DbContextOptions<CRUD_Application_2Context> options)
            : base(options)
        {
        }

        public DbSet<CRUD_Application_2.Model.User> User { get; set; } = default!;
    }
}
